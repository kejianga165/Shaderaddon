#version 150

#define TAU 6.28318530718

uniform sampler2D DiffuseSampler;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

uniform float u_ShaderTime;
uniform vec2 u_Resolution;

uniform float u_Width;

uniform int u_GlowInside;
uniform int u_GlowQuality;
uniform float u_GlowMultiplier;

uniform float u_FillAlpha;
uniform float u_OutlineAlpha;

uniform int u_FillMode;
uniform vec4 u_GradientColor;
uniform float u_GradientFactor;

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

vec4 getFill(vec3 centerColor, float alpha) {
    if (u_FillMode == 1) {
        float time = u_ShaderTime / 5.0;
        float distance = sqrt(gl_FragCoord.x * gl_FragCoord.x + gl_FragCoord.y * gl_FragCoord.y) + time;
        distance = distance / u_GradientFactor;
        distance = ((sin(distance) + 1.0) / 2.0);
        float j = 1.0 - distance;
        float r = centerColor.r * distance + u_GradientColor.r * j;
        float g = centerColor.g * distance + u_GradientColor.g * j;
        float b = centerColor.b * distance + u_GradientColor.b * j;
        // Blend color only — keep the user's fill opacity so the gradient never
        // turns into fully opaque color patches.
        return vec4(r, g, b, alpha);
    }

    if (u_FillMode == 4) {
        float zoom = 1;
        vec2 uv = (gl_FragCoord.xy / u_Resolution.xy - 0.5) * zoom + 0.5;
        float theta = uv.x * 3.14159;
        float phi = uv.y * 3.14159 * 0.5;
        vec3 dir = vec3(cos(phi) * cos(theta), sin(phi), cos(phi) * sin(theta));
        float time = u_ShaderTime / 750.0;
        float rot = time * 0.2;
        mat2 rotMat = mat2(cos(rot), -sin(rot), sin(rot), cos(rot));
        dir.xz = rotMat * dir.xz;
        float dist = length(dir.xy);
        float angle = atan(dir.y, dir.x);
        float spiral = sin(dist * 10.0 - angle * 3.0 - time * 2.0);
        float hue = fract(dist * 2.0 - time * 0.3 + angle / 6.28318);
        vec3 rainbowColor = hsv2rgb(vec3(hue, 0.8, 1.0));
        float rings = sin(dist * 20.0 - time * 3.0);
        rings = pow(max(0.0, rings), 3.0);
        vec3 finalColor = rainbowColor * (spiral * 0.3 + 0.7);
        finalColor += vec3(1.0) * rings * 0.5;
        float glow = exp(-dist * 3.0);
        finalColor += vec3(1.0, 0.9, 1.0) * glow * 0.5;
        return vec4(finalColor, alpha);
    }

    return vec4(centerColor, alpha);
}

// Gaussian glow. Blurs the *continuous* alpha (no binary mask) with a wide,
// slowly-decaying kernel, so soft edges become a real haze instead of hard
// bands. step is fixed at 1 — sparse sampling was what produced the vertical
// striping on thin geometry.
float blur(vec2 uv)
{
    if (u_Width < 0.5) return 0.0;

    int step = max(u_GlowQuality, 1);
    int w = int(max(u_Width, 1.0)) * step;
    if (w == 0) return 0.0;

    float blurred = 0.0;
    float totalWeight = 0.0;

    float sigma = float(w) * 0.6;
    float twoSigmaSq = 2.0 * sigma * sigma;

    // 黄金角螺旋采样：点不会排成整齐的行列，周期性被打散
    const float GOLDEN = 2.39996323;
    int samples = 0;
    // 总点数按面积估，够用就行
    int maxSamples = (2 * w + 1) * (2 * w + 1) / (step * step);

    for (int i = 0; i < maxSamples; i++) {
        float fi = float(i) + 0.5;
        float r = sqrt(fi / float(maxSamples)) * float(w);
        float a = fi * GOLDEN;
        vec2 offset = vec2(cos(a), sin(a)) * r;

        float d2 = dot(offset, offset);
        float weight = exp(-d2 / twoSigmaSq);
        blurred += texture(DiffuseSampler, uv + oneTexel * offset).a * weight;
        totalWeight += weight;
    }

    return clamp(blurred / max(totalWeight, 0.0001), 0.0, 1.0) * u_GlowMultiplier;
}

void main()
{
    vec4 center = texture(DiffuseSampler, texCoord);

    if (center.a > 0.0)
    {
        vec4 fill = getFill(center.rgb, u_FillAlpha);
        if (u_GlowInside == 1)
        {
            vec4 outline = vec4(getFill(center.rgb, 1.0).rgb, u_OutlineAlpha);
            // Softer inside blend: the glow now reaches further, so bias toward
            // the fill a bit more or the inner glow swallows the body.
            float insideMix = clamp((u_GlowMultiplier - blur(texCoord)) * 0.85, 0.0, 1.0);
            fragColor = mix(fill, outline, insideMix);
        } else {
            fragColor = fill;
        }
        return;
    }

    float glow = blur(texCoord);
    if (glow < 0.001)
    {
        discard;
    }

    vec3 outlineRGB = vec3(0.0);
    bool edge = false;
    // width*quality can reach 25 rings at max settings (200 taps per pixel);
    // cap the search so extreme settings stay affordable, glow just stops a
    // little earlier.
    int maxR = min(int(max(u_Width, 1.0)) * max(u_GlowQuality, 1), 10);

    for (int r = 1; r <= maxR; r += 1) {
        vec2 dx = vec2(oneTexel.x * float(r), 0.0);
        vec2 dy = vec2(0.0, oneTexel.y * float(r));

        vec4 s = texture(DiffuseSampler, texCoord - dx);
        if (s.a > 0.0) { outlineRGB = s.rgb; if (r == 1) edge = true; break; }

        s = texture(DiffuseSampler, texCoord + dx);
        if (s.a > 0.0) { outlineRGB = s.rgb; if (r == 1) edge = true; break; }

        s = texture(DiffuseSampler, texCoord - dy);
        if (s.a > 0.0) { outlineRGB = s.rgb; if (r == 1) edge = true; break; }

        s = texture(DiffuseSampler, texCoord + dy);
        if (s.a > 0.0) { outlineRGB = s.rgb; if (r == 1) edge = true; break; }

        vec2 od = vec2(dx.x, dy.y);
        s = texture(DiffuseSampler, texCoord + od);
        if (s.a > 0.0) { outlineRGB = s.rgb; if (r == 1) edge = true; break; }

        s = texture(DiffuseSampler, texCoord + vec2(od.x, -od.y));
        if (s.a > 0.0) { outlineRGB = s.rgb; if (r == 1) edge = true; break; }

        s = texture(DiffuseSampler, texCoord + vec2(-od.x, od.y));
        if (s.a > 0.0) { outlineRGB = s.rgb; if (r == 1) edge = true; break; }

        s = texture(DiffuseSampler, texCoord - od);
        if (s.a > 0.0) { outlineRGB = s.rgb; if (r == 1) edge = true; break; }
    }

    vec3 fillOutline = getFill(outlineRGB, 1.0).rgb;
    if (edge) {
        fragColor = vec4(fillOutline, u_OutlineAlpha);
    } else {
        fragColor = vec4(fillOutline, glow * u_OutlineAlpha);
    }
}
