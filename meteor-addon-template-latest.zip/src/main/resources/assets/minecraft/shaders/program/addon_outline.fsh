#version 330

#define TAU 6.28318530718

uniform sampler2D DiffuseSampler;

in vec2 texCoord;
in vec2 oneTexel;

uniform vec2 InSize;
uniform int RenderMode;
uniform float FillOpacity;
uniform vec4 OutlineColor;
uniform vec4 FriendColor;
uniform float OutlineWidth;

uniform int u_FillMode;
uniform float u_ShaderTime;
uniform vec2 u_Resolution;
uniform vec4 u_GradientColor;
uniform float u_GradientFactor;

out vec4 fragColor;

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

vec4 getFill(vec3 centerColor, float alpha) {
    if (u_FillMode == 1) {
        float time = u_ShaderTime / 5.0;
        float distance = sqrt(gl_FragCoord.x * gl_FragCoord.x + gl_FragCoord.y * gl_FragCoord.y) + time;
        distance = distance / u_GradientFactor;
        distance = ((sin(distance) + 1.0) / 2.0);
        float j = 1.0 - distance;
        float r = centerColor.r * distance + u_GradientColor.r * j;
        float g = centerColor.g * distance + u_GradientColor.g * j;
        float b = centerColor.b * distance + u_GradientColor.b * j;
        // Blend color only — keep the user's fill opacity so the gradient never
        // turns into fully opaque color patches.
        return vec4(r, g, b, alpha);
    }

    if (u_FillMode == 4) {
        float zoom = 1;
        vec2 uv = (gl_FragCoord.xy / u_Resolution.xy - 0.5) * zoom + 0.5;
        float theta = uv.x * 3.14159;
        float phi = uv.y * 3.14159 * 0.5;
        vec3 dir = vec3(cos(phi) * cos(theta), sin(phi), cos(phi) * sin(theta));
        float time = u_ShaderTime / 750.0;
        float rot = time * 0.2;
        mat2 rotMat = mat2(cos(rot), -sin(rot), sin(rot), cos(rot));
        dir.xz = rotMat * dir.xz;
        float dist = length(dir.xy);
        float angle = atan(dir.y, dir.x);
        float spiral = sin(dist * 10.0 - angle * 3.0 - time * 2.0);
        float hue = fract(dist * 2.0 - time * 0.3 + angle / 6.28318);
        vec3 rainbowColor = hsv2rgb(vec3(hue, 0.8, 1.0));
        float rings = sin(dist * 20.0 - time * 3.0);
        rings = pow(max(0.0, rings), 3.0);
        vec3 finalColor = rainbowColor * (spiral * 0.3 + 0.7);
        finalColor += vec3(1.0) * rings * 0.5;
        float glow = exp(-dist * 3.0);
        finalColor += vec3(1.0, 0.9, 1.0) * glow * 0.5;
        return vec4(finalColor, alpha);
    }

    return vec4(centerColor, alpha);
}

// Distance (in texels, capped at FEATHER) from an inside pixel to the silhouette
// edge, sampled in 16 directions. More directions than the old 8-direction
// version means diagonal/curved edges get a much more accurate distance, so the
// fill feathering stays even around slopes and round models.
const int FEATHER = 5;

float edgeDistance(vec2 uv) {
    // 16 unit directions (every 22.5 degrees). Being unit-length means `r`
    // is already the true Euclidean distance, so no 0.7071 correction needed.
    vec2 dirs[16] = vec2[16](
        vec2( 1.0000,  0.0000),
        vec2( 0.9239,  0.3827),
        vec2( 0.7071,  0.7071),
        vec2( 0.3827,  0.9239),
        vec2( 0.0000,  1.0000),
        vec2(-0.3827,  0.9239),
        vec2(-0.7071,  0.7071),
        vec2(-0.9239,  0.3827),
        vec2(-1.0000,  0.0000),
        vec2(-0.9239, -0.3827),
        vec2(-0.7071, -0.7071),
        vec2(-0.3827, -0.9239),
        vec2( 0.0000, -1.0000),
        vec2( 0.3827, -0.9239),
        vec2( 0.7071, -0.7071),
        vec2( 0.9239, -0.3827)
    );

    for (int r = 1; r <= FEATHER; r++) {
        for (int d = 0; d < 16; d++) {
            vec2 off = dirs[d] * oneTexel * float(r);
            if (texture(DiffuseSampler, uv + off).a == 0.0) {
                return float(r - 1);
            }
        }
    }
    return float(FEATHER);
}

void main() {
    vec4 current = texture(DiffuseSampler, texCoord);

    if (current.a > 0.0) {
        if (RenderMode == 1) discard;
        vec4 fill = getFill(current.rgb, FillOpacity);
        // Fade toward the edge, but keep a floor so model-part joints don't
        // split the fill into separate looking patches.
        float fade = mix(0.25, 1.0, smoothstep(0.0, float(FEATHER), edgeDistance(texCoord)));
        fragColor = vec4(fill.rgb, current.a * fill.a * fade);
    } else {
        if (RenderMode == 0) discard;

        float maxR = ceil(OutlineWidth + 1.0);
        float alpha = 0.0;
        vec3 nearestColor = vec3(0.0);

        // Scan outward ring by ring: edge weight decreases with distance, so the
        // nearest ring containing an opaque pixel always holds the final value and
        // the scan can stop there instead of covering the whole square.
        bool found = false;
        for (float r = 1.0; r <= maxR && !found; r += 1.0) {
            for (float x = -r; x <= r; x += 1.0) {
                vec2 offsets[2];
                offsets[0] = vec2(x, -r);
                offsets[1] = vec2(x, r);
                for (int i = 0; i < 2; i++) {
                    float dist = length(offsets[i]);
                    if (dist > maxR) continue;

                    vec4 tex = texture(DiffuseSampler, texCoord + offsets[i] * oneTexel);
                    if (tex.a > 0.0) {
                        found = true;
                        float edge = 1.0 - smoothstep(OutlineWidth, OutlineWidth + 1.0, dist);
                        if (edge > alpha) {
                            alpha = edge;
                            nearestColor = tex.rgb;
                        }
                    }
                }
            }
            for (float y = -r + 1.0; y <= r - 1.0; y += 1.0) {
                vec2 offsets[2];
                offsets[0] = vec2(-r, y);
                offsets[1] = vec2(r, y);
                for (int i = 0; i < 2; i++) {
                    float dist = length(offsets[i]);
                    if (dist > maxR) continue;

                    vec4 tex = texture(DiffuseSampler, texCoord + offsets[i] * oneTexel);
                    if (tex.a > 0.0) {
                        found = true;
                        float edge = 1.0 - smoothstep(OutlineWidth, OutlineWidth + 1.0, dist);
                        if (edge > alpha) {
                            alpha = edge;
                            nearestColor = tex.rgb;
                        }
                    }
                }
            }
        }

        if (alpha > 0.0) {
            vec3 finalOutlineColor = OutlineColor.rgb;
            if (FriendColor.a >= 0.0 && distance(nearestColor, FriendColor.rgb) < 0.05) {
                finalOutlineColor = FriendColor.rgb;
            }
            fragColor = vec4(getFill(finalOutlineColor, 1.0).rgb, alpha * OutlineColor.a);
        } else {
            discard;
        }
    }
}
