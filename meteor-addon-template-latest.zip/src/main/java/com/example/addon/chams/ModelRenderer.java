package com.example.addon.chams;

import com.example.addon.mixin.RenderLayerMultiPhaseAccessor;
import com.example.addon.mixin.RenderPhaseAccessor;
import com.example.addon.mixin.RenderPhaseMultiPhaseParametersAccessor;
import com.example.addon.mixin.RenderPhaseTextureBaseAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EndCrystalEntityRenderer;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Optional;

/**
 * Ported from Zen's ModelRenderer, adapted to 1.21.1 (no render states):
 * re-renders an entity's model through a custom VertexConsumerProvider that
 * captures the transformed geometry as flat colored quads / outline lines /
 * glint quads instead of drawing it.
 */
public class ModelRenderer {

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static Render render;
    private static Matrix4f matrix4f;
    private static Vec3d offset;
    private static Vec3d camera;

    public static void renderModel(Entity entity, float scale, float tickDelta, Render render) {
        ModelRenderer.render = render;
        ModelRenderer.camera = mc.gameRenderer.getCamera().getPos();

        ModelRenderer.offset = new Vec3d(
            MathHelper.lerp(tickDelta, entity.lastRenderX, entity.getX()),
            MathHelper.lerp(tickDelta, entity.lastRenderY, entity.getY()),
            MathHelper.lerp(tickDelta, entity.lastRenderZ, entity.getZ())
        );

        EntityRenderer<?> renderer = mc.getEntityRenderDispatcher().getRenderer(entity);

        MatrixStack matrices = new MatrixStack();
        ModelRenderer.matrix4f = matrices.peek().getPositionMatrix();

        matrices.push();
        matrices.scale(scale, scale, scale);

        float yaw = entity.getYaw(tickDelta);

        if (entity instanceof LivingEntity livingEntity && renderer instanceof LivingEntityRenderer<?, ?> livingRenderer) {
            @SuppressWarnings({"unchecked", "rawtypes"})
            LivingEntityRenderer<LivingEntity, ?> entityRenderer = (LivingEntityRenderer) livingRenderer;
            entityRenderer.render(livingEntity, yaw, tickDelta, matrices, CustomVertexConsumerProvider.INSTANCE, 15);
        }

        if (entity instanceof EndCrystalEntity crystal && renderer instanceof EndCrystalEntityRenderer crystalRenderer) {
            crystalRenderer.render(crystal, yaw, tickDelta, matrices, CustomVertexConsumerProvider.INSTANCE, 15);
        }

        matrices.pop();
    }

    private static class CustomVertexConsumerProvider implements VertexConsumerProvider {
        public static final CustomVertexConsumerProvider INSTANCE = new CustomVertexConsumerProvider();

        @Override
        public VertexConsumer getBuffer(RenderLayer layer) {
            // Whitelist the plain body-model layers by layer name. Armor and elytra
            // use their own layers ("armor_cutout_no_cull", ...), label text is not
            // a MultiPhase layer.
            if (!(layer instanceof RenderLayer.MultiPhase)) return new EmptyVertexConsumer();

            switch (((RenderPhaseAccessor) layer).getName()) {
                case "entity_cutout_no_cull":
                case "entity_translucent":
                case "entity_translucent_cull":
                case "entity_cutout":
                    // Held items render through the same "entity_cutout" name but with
                    // a shared atlas texture — body models always use per-entity
                    // textures/entity/... files, so exclude atlas-backed layers.
                    //
                    // Chain: MultiPhase -> phases (MultiPhaseParameters)
                    //        -> texture (TextureBase)
                    //        -> getId()
                    RenderLayer.MultiPhaseParameters phases =
                        ((RenderLayerMultiPhaseAccessor) layer).invokeGetPhases();

                    RenderPhase.TextureBase texture =
                        ((RenderPhaseMultiPhaseParametersAccessor) (Object) phases).getTexture();

                    Optional<Identifier> texId =
                        ((RenderPhaseTextureBaseAccessor) (Object) texture).invokeGetId();

                    if (texId.isPresent() && texId.get().getPath().startsWith("textures/atlas/")) {
                        return new EmptyVertexConsumer();
                    }
                    return new CustomVertexConsumer();
                default:
                    return new EmptyVertexConsumer();
            }
        }
    }

    private static class CustomVertexConsumer implements VertexConsumer {
        private final float[] xs = new float[4];
        private final float[] ys = new float[4];
        private final float[] zs = new float[4];

        private int i = 0;

        @Override
        public VertexConsumer vertex(float x, float y, float z) {
            xs[i] = x;
            ys[i] = y;
            zs[i] = z;

            i++;

            if (i == 4) {
                List<Renderer3D.VertexCollection> quads = render.shine() ? Renderer3D.SHINE_QUADS : Renderer3D.QUADS;
                List<Renderer3D.VertexCollection> debugLines = render.shine() ? Renderer3D.SHINE_DEBUG_LINES : Renderer3D.DEBUG_LINES;

                if (render.fill()) {
                    quads.add(new Renderer3D.VertexCollection(
                        new Renderer3D.Vertex(matrix4f, (float)(offset.getX() + xs[0] - camera.getX()), (float)(offset.getY() + ys[0] - camera.getY()), (float)(offset.getZ() + zs[0] - camera.getZ()), toArgb(render.fillColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.getX() + xs[1] - camera.getX()), (float)(offset.getY() + ys[1] - camera.getY()), (float)(offset.getZ() + zs[1] - camera.getZ()), toArgb(render.fillColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.getX() + xs[2] - camera.getX()), (float)(offset.getY() + ys[2] - camera.getY()), (float)(offset.getZ() + zs[2] - camera.getZ()), toArgb(render.fillColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.getX() + xs[3] - camera.getX()), (float)(offset.getY() + ys[3] - camera.getY()), (float)(offset.getZ() + zs[3] - camera.getZ()), toArgb(render.fillColor()))
                    ));
                }

                if (render.outline()) {
                    debugLines.add(new Renderer3D.VertexCollection(
                        new Renderer3D.Vertex(matrix4f, (float)(offset.x + xs[0] - camera.getX()), (float)(offset.y + ys[0] - camera.getY()), (float)(offset.z + zs[0] - camera.getZ()), toArgb(render.outlineColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.x + xs[1] - camera.getX()), (float)(offset.y + ys[1] - camera.getY()), (float)(offset.z + zs[1] - camera.getZ()), toArgb(render.outlineColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.x + xs[1] - camera.getX()), (float)(offset.y + ys[1] - camera.getY()), (float)(offset.z + zs[1] - camera.getZ()), toArgb(render.outlineColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.x + xs[2] - camera.getX()), (float)(offset.y + ys[2] - camera.getY()), (float)(offset.z + zs[2] - camera.getZ()), toArgb(render.outlineColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.x + xs[2] - camera.getX()), (float)(offset.y + ys[2] - camera.getY()), (float)(offset.z + zs[2] - camera.getZ()), toArgb(render.outlineColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.x + xs[3] - camera.getX()), (float)(offset.y + ys[3] - camera.getY()), (float)(offset.z + zs[3] - camera.getZ()), toArgb(render.outlineColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.x + xs[0] - camera.getX()), (float)(offset.y + ys[0] - camera.getY()), (float)(offset.z + zs[0] - camera.getZ()), toArgb(render.outlineColor())),
                        new Renderer3D.Vertex(matrix4f, (float)(offset.x + xs[0] - camera.getX()), (float)(offset.y + ys[0] - camera.getY()), (float)(offset.z + zs[0] - camera.getZ()), toArgb(render.outlineColor()))
                    ));
                }

                if (render.glint()) {
                    float[] uArr = new float[4];
                    float[] vArr = new float[4];
                    for (int vi = 0; vi < 4; vi++) {
                        float[] uv = Glint.getGlintUV(xs[vi], ys[vi], zs[vi]);
                        uArr[vi] = uv[0];
                        vArr[vi] = uv[1];
                    }
                    Glint.QUADS.add(new Glint.TexturedVertexCollection(
                        new Glint.TexturedVertex(matrix4f, (float)(offset.getX() + xs[0] - camera.getX()), (float)(offset.getY() + ys[0] - camera.getY()), (float)(offset.getZ() + zs[0] - camera.getZ()), uArr[0], vArr[0], toArgb(render.glintColor())),
                        new Glint.TexturedVertex(matrix4f, (float)(offset.getX() + xs[1] - camera.getX()), (float)(offset.getY() + ys[1] - camera.getY()), (float)(offset.getZ() + zs[1] - camera.getZ()), uArr[1], vArr[1], toArgb(render.glintColor())),
                        new Glint.TexturedVertex(matrix4f, (float)(offset.getX() + xs[2] - camera.getX()), (float)(offset.getY() + ys[2] - camera.getY()), (float)(offset.getZ() + zs[2] - camera.getZ()), uArr[2], vArr[2], toArgb(render.glintColor())),
                        new Glint.TexturedVertex(matrix4f, (float)(offset.getX() + xs[3] - camera.getX()), (float)(offset.getY() + ys[3] - camera.getY()), (float)(offset.getZ() + zs[3] - camera.getZ()), uArr[3], vArr[3], toArgb(render.glintColor()))
                    ));
                }

                i = 0;
            }

            return this;
        }

        @Override
        public VertexConsumer color(int red, int green, int blue, int alpha) {
            return this;
        }

        @Override
        public VertexConsumer texture(float u, float v) {
            return this;
        }

        @Override
        public VertexConsumer overlay(int u, int v) {
            return this;
        }

        @Override
        public VertexConsumer light(int u, int v) {
            return this;
        }

        @Override
        public VertexConsumer normal(float x, float y, float z) {
            return this;
        }
    }

    private static class EmptyVertexConsumer implements VertexConsumer {
        @Override
        public VertexConsumer vertex(float x, float y, float z) {
            return this;
        }

        @Override
        public VertexConsumer color(int red, int green, int blue, int alpha) {
            return this;
        }

        @Override
        public VertexConsumer texture(float u, float v) {
            return this;
        }

        @Override
        public VertexConsumer overlay(int u, int v) {
            return this;
        }

        @Override
        public VertexConsumer light(int u, int v) {
            return this;
        }

        @Override
        public VertexConsumer normal(float x, float y, float z) {
            return this;
        }
    }

    private static int toArgb(meteordevelopment.meteorclient.utils.render.color.Color color) {
        return (color.a << 24) | (color.r << 16) | (color.g << 8) | color.b;
    }

    public record Render(boolean fill, meteordevelopment.meteorclient.utils.render.color.Color fillColor, boolean outline, meteordevelopment.meteorclient.utils.render.color.Color outlineColor, boolean shine, boolean glint, meteordevelopment.meteorclient.utils.render.color.Color glintColor) {}
}
