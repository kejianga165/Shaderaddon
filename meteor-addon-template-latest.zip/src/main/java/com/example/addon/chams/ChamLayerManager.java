package com.example.addon.chams;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.GL11;

/**
 * Ported from Zen's RenderLayerManager. Builds the XQZ layer used to render the
 * textured entity model through walls: Zen's TO_FRONT layering relied on the
 * 1.21.2+ projection-type API, so on 1.21.1 the same effect is achieved with an
 * always-pass depth test and a color-only write mask.
 */
public final class ChamLayerManager {

    private static final RenderPhase.DepthTest ALWAYS_NO_DEPTH_TEST = new RenderPhase.DepthTest("addon_always_depth_test", GL11.GL_ALWAYS);

    private ChamLayerManager() {}

    public static RenderLayer getRenderLayer(Identifier texture, float alpha) {
        boolean translucent = alpha < 1.0f;
        return RenderLayer.of("addon_entity",
            VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL,
            VertexFormat.DrawMode.QUADS, 1536, true, true,
            RenderLayer.MultiPhaseParameters.builder()
                .program(translucent ? RenderPhase.ENTITY_TRANSLUCENT_PROGRAM : RenderPhase.ENTITY_CUTOUT_PROGRAM)
                .texture(new RenderPhase.Texture(texture, false, false))
                .lightmap(RenderLayer.ENABLE_LIGHTMAP)
                .transparency(translucent ? RenderPhase.TRANSLUCENT_TRANSPARENCY : RenderPhase.NO_TRANSPARENCY)
                .depthTest(ALWAYS_NO_DEPTH_TEST)
                .writeMaskState(RenderPhase.COLOR_MASK)
                .overlay(RenderLayer.ENABLE_OVERLAY_COLOR)
                .build(true));
    }
}
