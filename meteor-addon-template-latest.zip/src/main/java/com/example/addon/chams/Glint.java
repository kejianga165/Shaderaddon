package com.example.addon.chams;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

/**
 * Ported from Zen's Glint: collects textured quads while chams models are being
 * "rendered" and draws a scrolling overlay texture on top of them.
 */
public class Glint {

    public static List<TexturedVertexCollection> QUADS = new ArrayList<>();

    public static float speedU = 0.25f;
    public static float speedV = 0.10f;
    public static float scale = 1.0f;
    public static String direction = "Diagonal";

    private static float scrollU = 0f;
    private static float scrollV = 0f;
    private static long lastMs = 0L;

    public static void tick() {
        QUADS.clear();

        long nowMs = System.currentTimeMillis();
        if (lastMs == 0L) lastMs = nowMs;
        float delta = (nowMs - lastMs) / 1000f;
        lastMs = nowMs;

        scrollU = (scrollU + speedU * delta) % 1f;
        scrollV = (scrollV + speedV * delta) % 1f;
        if (scrollU < 0f) scrollU += 1f;
        if (scrollV < 0f) scrollV += 1f;
    }

    public static float[] getGlintUV(float x, float y, float z) {
        float u, v;
        float s = scale * 0.06f;  // base coefficient
        switch (direction) {
            case "Horizontal":
                u = (x + z * 0.5f) * s;
                v = y * s;
                break;
            case "Vertical":
                u = y * s;
                v = (x + z * 0.5f) * s;
                break;
            default:
                u = x * s + z * s * 0.5f;
                v = y * s + z * s * 0.5f;
                break;
        }
        u += scrollU;
        v += scrollV;
        return new float[]{u, v};
    }

    public static void draw() {
        if (QUADS.isEmpty()) return;

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(770, 32772);
        RenderSystem.disableDepthTest();

        BufferBuilder buffer = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        for (TexturedVertexCollection collection : QUADS)
            collection.vertex(buffer);

        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        RenderSystem.setShaderTexture(0, Identifier.of("addon-template", "textures/glint.png"));
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_REPEAT);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL11.GL_REPEAT);
        RenderSystem.disableCull();

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    public record TexturedVertexCollection(TexturedVertex... vertices) {
        public void vertex(BufferBuilder buffer) {
            for (TexturedVertex vertex : vertices)
                buffer.vertex(vertex.matrix, vertex.x, vertex.y, vertex.z).texture(vertex.u, vertex.v).color(vertex.color);
        }
    }

    public record TexturedVertex(org.joml.Matrix4f matrix, float x, float y, float z, float u, float v, int color) {}
}
