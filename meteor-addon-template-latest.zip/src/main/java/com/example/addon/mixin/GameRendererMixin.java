package com.example.addon.mixin;

import com.example.addon.modules.ShadersModule;

import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @Inject(method = "renderWorld", at = @At("TAIL"))
    private void addon$onRenderWorldTail(RenderTickCounter tickCounter, CallbackInfo info) {
        ShadersModule module = ShadersModule.get();
        if (module != null) module.onWorldRenderPost();
    }
}
