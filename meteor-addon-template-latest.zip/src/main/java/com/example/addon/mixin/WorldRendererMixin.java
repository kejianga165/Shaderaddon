package com.example.addon.mixin;

import com.example.addon.chams.Glint;
import com.example.addon.chams.Renderer3D;
import com.example.addon.shader.ShaderManager;
import com.example.addon.modules.ChamsModule;
import com.example.addon.modules.ShadersModule;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void addon$prepareShader(RenderTickCounter tickCounter, boolean renderBlockOutline, Camera camera, GameRenderer gameRenderer, LightmapTextureManager lightmapTextureManager, Matrix4f positionMatrix, Matrix4f projectionMatrix, CallbackInfo info) {
        ShadersModule module = ShadersModule.get();
        if (module != null) module.onWorldRenderPrepare();
    }

    @WrapOperation(method = "renderEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/EntityRenderDispatcher;render(Lnet/minecraft/entity/Entity;DDDFFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"))
    private <E extends Entity> void addon$renderEntity(EntityRenderDispatcher instance, E entity, double x, double y, double z, float tickDelta, float yaw, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, Operation<Void> original) {
        ShadersModule module = ShadersModule.get();
        VertexConsumerProvider wrapped = module != null ? module.onRenderEntity(entity, vertexConsumers) : vertexConsumers;

        original.call(instance, entity, x, y, z, tickDelta, yaw, matrices, wrapped, light);
    }

    // The camera matrix lives on the RenderSystem modelview stack only between the
    // pushMatrix()/popMatrix() pair inside WorldRenderer.render. Any buffered outline
    // geometry still unflushed at popMatrix time would be drawn without the camera
    // transform (outline drifting with the view), so flush it right before the pop.
    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lorg/joml/Matrix4fStack;popMatrix()Lorg/joml/Matrix4fStack;", shift = At.Shift.BEFORE))
    private void addon$onEntitiesRendered(RenderTickCounter tickCounter, boolean renderBlockOutline, Camera camera, GameRenderer gameRenderer, LightmapTextureManager lightmapTextureManager, Matrix4f positionMatrix, Matrix4f projectionMatrix, CallbackInfo info) {
        ShadersModule module = ShadersModule.get();
        if (module != null) module.onRenderEntitiesPost();

        // Chams models are collected and drawn in camera-relative space while the
        // camera matrix is still active (same window as the shader flush above).
        ChamsModule chams = ChamsModule.get();
        if (chams != null && chams.isActive()) {
            Renderer3D.prepare();
            chams.onRenderWorld(tickCounter.getTickDelta(true));
            Renderer3D.draw(Renderer3D.QUADS, Renderer3D.DEBUG_LINES, false);
            Renderer3D.draw(Renderer3D.SHINE_QUADS, Renderer3D.SHINE_DEBUG_LINES, true);
            Glint.draw();
        }
    }

    @Inject(method = "onResized", at = @At("TAIL"))
    private void addon$onResized(int width, int height, CallbackInfo info) {
        ShaderManager.get().resize(width, height);
    }

    // The entity loop skips entities whose render chunk is currently rebuilding
    // (ChunkData EMPTY), which makes the through-wall highlight flicker off while
    // terrain updates. Bypass while the shader module owns those entities anyway.
    @Inject(method = "isRenderingReady", at = @At("HEAD"), cancellable = true)
    private void addon$alwaysRenderingReady(net.minecraft.util.math.BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        ShadersModule module = ShadersModule.get();
        if (module != null && module.isActive()) cir.setReturnValue(true);
    }
}
