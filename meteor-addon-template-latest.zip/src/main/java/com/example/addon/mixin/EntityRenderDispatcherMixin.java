package com.example.addon.mixin;

import com.example.addon.modules.ShadersModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {

    /**
     * Entities are frustum-culled by their render bounding box; at grazing angles or
     * near screen edges the box can drop out of the frustum for a few frames, which
     * silently removes the entity from the render list and with it the through-wall
     * highlight. Force-render everything the Shaders module would highlight anyway
     * (isValidEntity already applies the module's own distance setting).
     */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <E extends Entity> void addon$forceRender(E entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        ShadersModule module = ShadersModule.get();
        if (module == null || !module.isActive()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        if (module.isValidEntity(entity)) cir.setReturnValue(true);
    }
}
