package com.example.addon.mixin;

import com.example.addon.chams.ChamLayerManager;
import com.example.addon.modules.ChamsModule;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * XQZ part of Zen's chams, adapted to 1.21.1 (render takes the entity directly,
 * no render state capture needed): swaps the entity's render layer for a
 * through-walls translucent layer and dims it via the global shader color.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<T extends LivingEntity, M extends net.minecraft.client.render.entity.model.EntityModel<T>> {

    @Inject(method = "getRenderLayer", at = @At("HEAD"), cancellable = true)
    private void addon$xqzLayer(T entity, boolean showBody, boolean translucent, boolean showOutline, CallbackInfoReturnable<RenderLayer> cir) {
        ChamsModule chams = ChamsModule.get();
        if (chams == null || !chams.isXqzEntity(entity)) return;

        // getTexture is declared on the superclass and can't be @Shadow'd here.
        EntityRenderer<T> renderer = (EntityRenderer<T>) (Object) this;
        cir.setReturnValue(ChamLayerManager.getRenderLayer(renderer.getTexture(entity), chams.getXqzEntityOpacity()));
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/model/EntityModel;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V", shift = At.Shift.BEFORE))
    private void addon$xqzBeforeModel(T entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo cir) {
        ChamsModule chams = ChamsModule.get();
        if (chams == null || !chams.isXqzEntity(entity)) return;

        float alpha = chams.getXqzEntityOpacity();
        if (alpha < 1.0f) RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, alpha);
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/model/EntityModel;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V", shift = At.Shift.AFTER))
    private void addon$xqzAfterModel(T entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo cir) {
        ChamsModule chams = ChamsModule.get();
        if (chams == null || !chams.isXqzEntity(entity)) return;

        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    }
}
