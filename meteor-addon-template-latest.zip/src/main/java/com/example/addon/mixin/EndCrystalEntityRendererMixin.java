package com.example.addon.mixin;

import com.example.addon.chams.ChamLayerManager;
import com.example.addon.modules.ChamsModule;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EndCrystalEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

/**
 * XQZ part of Zen's crystal chams, adapted to 1.21.1: replaces the crystal
 * render layer with a through-walls translucent layer.
 */
@Mixin(EndCrystalEntityRenderer.class)
public abstract class EndCrystalEntityRendererMixin {

    @Shadow @Final private static Identifier TEXTURE;

    @WrapOperation(method = "render(Lnet/minecraft/entity/decoration/EndCrystalEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/VertexConsumerProvider;getBuffer(Lnet/minecraft/client/render/RenderLayer;)Lnet/minecraft/client/render/VertexConsumer;"))
    private VertexConsumer addon$xqzLayer(VertexConsumerProvider instance, RenderLayer original, Operation<VertexConsumer> operation, EndCrystalEntity entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        ChamsModule chams = ChamsModule.get();
        if (chams != null && chams.isXqzCrystal(entity)) {
            return instance.getBuffer(ChamLayerManager.getRenderLayer(TEXTURE, chams.getXqzCrystalOpacity()));
        }

        return operation.call(instance, original);
    }
}
