package com.example.addon.shader;

import com.example.addon.mixin.PostEffectProcessorAccessor;
import com.example.addon.mixin.RenderLayerMultiPhaseAccessor;
import com.example.addon.mixin.RenderLayerMultiPhaseParametersAccessor;
import com.example.addon.mixin.RenderPhaseTextureBaseAccessor;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.JsonEffectShaderProgram;
import net.minecraft.client.gl.PostEffectPass;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.OutlineVertexConsumerProvider;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumers;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

/**
 * Ported from Zen's ShaderManager (me.nosvo.zen.api.managers.ShaderManager), adapted to the
 * 1.21.1 post-effect API: entities are drawn into a private framebuffer through an
 * OutlineVertexConsumerProvider render layer, then post-processed with the
 * "addon_outline" / "addon_bloom" programs via a manually built PostEffectProcessor.
 */
public class ShaderManager {

    private static final String MOD_ID = "addon-template";
    private static final long startTime = System.currentTimeMillis();

    private static ShaderManager instance;

    public static ShaderManager get() {
        if (instance == null) instance = new ShaderManager();
        return instance;
    }

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final OutlineVertexConsumerProvider vertexConsumerProvider = new OutlineVertexConsumerProvider(VertexConsumerProvider.immediate(new BufferAllocator(256)));
    private final SimpleFramebuffer framebuffer;
    private final SimpleFramebuffer resultFramebuffer;

    private final RenderPhase.Target target;
    private final Function<RenderPhase.TextureBase, RenderLayer> layerCreator;

    private PostEffectProcessor outlineProcessor;
    private PostEffectProcessor bloomProcessor;
    private int processorWidth = -1, processorHeight = -1;

    private int fillMode;
    private float gradientR, gradientG, gradientB, gradientA;
    private float gradientFactor;

    // Whether anything was drawn into the shader framebuffer this frame; lets us
    // skip the fullscreen post pass + blit entirely when no target was visible.
    // Starts true so the first prepare() clears the freshly created framebuffer.
    private boolean hasContent = true;

    // Reuses the wrapping VertexConsumerProvider lambda while parent and color are
    // unchanged, instead of allocating a new one per entity per frame.
    private VertexConsumerProvider cachedWrapper;
    private VertexConsumerProvider cachedWrapperParent;
    private int cachedWrapperR = -1, cachedWrapperG = -1, cachedWrapperB = -1;

    private ShaderManager() {
        framebuffer = new SimpleFramebuffer(mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight(), true, false);
        framebuffer.setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        resultFramebuffer = new SimpleFramebuffer(mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight(), true, false);
        resultFramebuffer.setClearColor(0.0f, 0.0f, 0.0f, 0.0f);

        // Matches vanilla's outline layer (RenderLayer.OUTLINE) phase-for-phase —
        // the recipe behind the vanilla Glowing effect, whose outline is drawn
        // ignoring depth and therefore visible through walls.
        target = new RenderPhase.Target("shader_target", () -> framebuffer.beginWrite(false), () -> mc.getFramebuffer().beginWrite(false));
        layerCreator = memoizeTexture(texture -> RenderLayer.of("addon_overlay", VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS, 1536, RenderLayer.MultiPhaseParameters.builder().program(RenderPhase.OUTLINE_PROGRAM).texture(texture).depthTest(RenderPhase.ALWAYS_DEPTH_TEST).transparency(RenderPhase.TRANSLUCENT_TRANSPARENCY).writeMaskState(RenderPhase.COLOR_MASK).cull(RenderPhase.DISABLE_CULLING).target(target).build(RenderLayer.OutlineMode.IS_OUTLINE)));
    }

    public OutlineVertexConsumerProvider getVertexConsumerProvider() {
        return vertexConsumerProvider;
    }

    public void prepare() {
        // The framebuffer only needs a clear after a frame that actually drew into it.
        if (hasContent) {
            framebuffer.setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            framebuffer.clear(false);
            hasContent = false;
        }

        mc.getFramebuffer().beginWrite(false);
    }

    public void setFillSettings(int fillMode, float gradientR, float gradientG, float gradientB, float gradientA, float gradientFactor) {
        this.fillMode = fillMode;
        this.gradientR = gradientR;
        this.gradientG = gradientG;
        this.gradientB = gradientB;
        this.gradientA = gradientA;
        this.gradientFactor = gradientFactor;
    }

    private void applyFillUniforms(JsonEffectShaderProgram program) {
        setUniform(program, "u_FillMode", fillMode);
        GlUniform gColor = program.getUniformByName("u_GradientColor");
        if (gColor != null) gColor.set(gradientR, gradientG, gradientB, gradientA);
        setUniform(program, "u_GradientFactor", gradientFactor);
    }

    /**
     * Builds (or rebuilds on window resize) a PostEffectProcessor for the given program.
     * The post json is an empty container; the single pass is added manually. PostEffectPass
     * clears its output before drawing, so the pass must write into an offscreen result
     * framebuffer — never the main one — and the result is blitted onto the main framebuffer
     * afterwards (see {@link #blitToMain()}).
     */
    private PostEffectProcessor getProcessor(PostEffectProcessor current, String programName) {
        int width = mc.getWindow().getFramebufferWidth();
        int height = mc.getWindow().getFramebufferHeight();

        if (current == null || width != processorWidth || height != processorHeight) {
            if (current != null) current.close();

            try {
                current = new PostEffectProcessor(mc.getTextureManager(), mc.getResourceManager(), mc.getFramebuffer(), Identifier.of(MOD_ID, "shaders/post/addon.json"));
                current.addPass(programName, framebuffer, resultFramebuffer, false);
                // addPass() alone leaves the pass without a projection matrix (NPE on render);
                // setupDimensions() rebuilds it and applies it to every pass.
                current.setupDimensions(width, height);
            } catch (IOException e) {
                throw new RuntimeException("Failed to load shader post effect: " + programName, e);
            }

            processorWidth = width;
            processorHeight = height;
        }

        return current;
    }

    private void blitToMain() {
        mc.getFramebuffer().beginWrite(false);

        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SrcFactor.ZERO, GlStateManager.DstFactor.ONE);

        resultFramebuffer.draw(mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight(), false);

        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    public void render(int renderMode, float fillOpacity, int outlineR, int outlineG, int outlineB, int outlineA, float outlineWidth, int friendR, int friendG, int friendB, int friendA) {
        if (!hasContent) return;

        outlineProcessor = getProcessor(outlineProcessor, "addon_outline");
        JsonEffectShaderProgram program = ((PostEffectProcessorAccessor) outlineProcessor).getPasses().getFirst().getProgram();

        setUniform(program, "RenderMode", renderMode);
        setUniform(program, "FillOpacity", fillOpacity);
        setUniform(program, "OutlineColor", outlineR / 255.0f, outlineG / 255.0f, outlineB / 255.0f, outlineA / 255.0f);
        setUniform(program, "FriendColor", friendR / 255.0f, friendG / 255.0f, friendB / 255.0f, friendA / 255.0f);
        setUniform(program, "OutlineWidth", outlineWidth);
        setUniform(program, "u_ShaderTime", (float) (System.currentTimeMillis() - startTime));
        setUniform(program, "u_Resolution", new float[]{mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight()});
        applyFillUniforms(program);

        program.markUniformsDirty();
        outlineProcessor.render(0.0f);
        blitToMain();
    }

    public void render(String shaderName, int renderMode, float fillOpacity, int glowInside, int glowQuality, float glowMultiplier, float width, float outlineAlpha, float shaderTime) {
        if (!hasContent) return;

        bloomProcessor = getProcessor(bloomProcessor, "addon_bloom");
        JsonEffectShaderProgram program = ((PostEffectProcessorAccessor) bloomProcessor).getPasses().getFirst().getProgram();

        setUniform(program, "RenderMode", renderMode);
        setUniform(program, "FillOpacity", fillOpacity);
        setUniform(program, "u_GlowInside", glowInside);
        setUniform(program, "u_GlowQuality", glowQuality);
        setUniform(program, "u_GlowMultiplier", glowMultiplier);
        setUniform(program, "u_Width", width);
        setUniform(program, "u_OutlineAlpha", outlineAlpha);
        setUniform(program, "u_FillAlpha", fillOpacity);
        setUniform(program, "u_ShaderTime", shaderTime);
        setUniform(program, "u_Resolution", new float[]{mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight()});
        applyFillUniforms(program);

        program.markUniformsDirty();
        bloomProcessor.render(0.0f);
        blitToMain();
    }

    private void setUniform(JsonEffectShaderProgram program, String name, int value) {
        GlUniform uniform = program.getUniformByName(name);
        if (uniform != null) uniform.set(value);
    }

    private void setUniform(JsonEffectShaderProgram program, String name, float value) {
        GlUniform uniform = program.getUniformByName(name);
        if (uniform != null) uniform.set(value);
    }

    private void setUniform(JsonEffectShaderProgram program, String name, float v1, float v2, float v3, float v4) {
        GlUniform uniform = program.getUniformByName(name);
        if (uniform != null) uniform.set(v1, v2, v3, v4);
    }

    private void setUniform(JsonEffectShaderProgram program, String name, float[] value) {
        GlUniform uniform = program.getUniformByName(name);
        if (uniform != null) uniform.set(value);
    }

    public void resize(int width, int height) {
        if (framebuffer != null) framebuffer.resize(width, height, true);
        if (resultFramebuffer != null) resultFramebuffer.resize(width, height, true);
        // Fresh GPU textures are undefined until cleared.
        hasContent = true;
        // Post effect processors are rebuilt lazily on the next render because their
        // projection matrix and dimensions are fixed at construction time.
    }

    public VertexConsumerProvider create(VertexConsumerProvider parent, int r, int g, int b) {
        if (cachedWrapper != null && parent == cachedWrapperParent && r == cachedWrapperR && g == cachedWrapperG && b == cachedWrapperB) {
            return cachedWrapper;
        }

        VertexConsumerProvider wrapper = layer -> {
            VertexConsumer parentBuffer = parent.getBuffer(layer);

            if (!(layer instanceof RenderLayer.MultiPhase) || ((RenderLayerMultiPhaseParametersAccessor) (Object) ((RenderLayerMultiPhaseAccessor) layer).invokeGetPhases()).getOutlineMode() == RenderLayer.OutlineMode.NONE) {
                return parentBuffer;
            }

            hasContent = true;
            vertexConsumerProvider.setColor(r, g, b, 255);

            VertexConsumer outlineBuffer = vertexConsumerProvider.getBuffer(layerCreator.apply(((RenderLayerMultiPhaseParametersAccessor) (Object) ((RenderLayerMultiPhaseAccessor) layer).invokeGetPhases()).getTexture()));
            return outlineBuffer != null ? VertexConsumers.union(outlineBuffer, parentBuffer) : parentBuffer;
        };

        cachedWrapper = wrapper;
        cachedWrapperParent = parent;
        cachedWrapperR = r;
        cachedWrapperG = g;
        cachedWrapperB = b;
        return wrapper;
    }

    private Function<RenderPhase.TextureBase, RenderLayer> memoizeTexture(Function<RenderPhase.TextureBase, RenderLayer> function) {
        return new Function<>() {
            private final Map<Identifier, RenderLayer> cache = new HashMap<>();

            public RenderLayer apply(RenderPhase.TextureBase texture) {
                Optional<Identifier> id = ((RenderPhaseTextureBaseAccessor) texture).invokeGetId();
                return this.cache.computeIfAbsent(id.orElse(Identifier.ofVanilla("missing")), missing -> function.apply(texture));
            }
        };
    }
}
