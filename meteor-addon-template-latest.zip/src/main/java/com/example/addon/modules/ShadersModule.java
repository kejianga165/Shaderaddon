package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import com.example.addon.shader.ShaderManager;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Ported from Zen's ShadersModule (me.nosvo.zen.client.modules.impl.visuals.ShadersModule).
 * Overlays specified entities (and/or your hands) with an outline or bloom shader.
 */
public class ShadersModule extends Module {
    public enum ShaderMode { Outline, Bloom }
    public enum Mode { Fill, Outline, Both }
    public enum FriendsMode { Default, Custom, Sync }
    public enum FillMode { Default, Gradient, Rainbow }

    private static final long startTime = System.currentTimeMillis();
    private static final SettingColor DEFAULT_FRIEND_COLOR = new SettingColor(85, 255, 255);

    private final SettingGroup sgTargets = settings.createGroup("Targets");
    private final SettingGroup sgShader = settings.createGroup("Shader");
    private final SettingGroup sgBloom = settings.createGroup("Bloom");
    private final SettingGroup sgFill = settings.createGroup("Fill");

    // Targets

    private final Setting<Boolean> players = sgTargets.add(new BoolSetting.Builder()
        .name("players")
        .description("Renders the shader effect on player entities.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> hostiles = sgTargets.add(new BoolSetting.Builder()
        .name("hostiles")
        .description("Renders the shader effect on hostile entities.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> animals = sgTargets.add(new BoolSetting.Builder()
        .name("animals")
        .description("Renders the shader effect on animal entities.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> ambient = sgTargets.add(new BoolSetting.Builder()
        .name("ambient")
        .description("Renders the shader effect on ambient entities.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> invisibles = sgTargets.add(new BoolSetting.Builder()
        .name("invisibles")
        .description("Renders the shader effect on invisible entities.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> items = sgTargets.add(new BoolSetting.Builder()
        .name("items")
        .description("Renders the shader effect on item entities.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> crystals = sgTargets.add(new BoolSetting.Builder()
        .name("crystals")
        .description("Renders the shader effect on crystal entities.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> others = sgTargets.add(new BoolSetting.Builder()
        .name("others")
        .description("Renders the shader effect on miscellaneous entities.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> hands = sgTargets.add(new BoolSetting.Builder()
        .name("hands")
        .description("Renders the shader effect on your hands.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Double> distance = sgTargets.add(new DoubleSetting.Builder()
        .name("distance")
        .description("The maximum distance at which entities get the shader effect.")
        .defaultValue(64.0)
        .range(0.0, 256.0)
        .sliderRange(8.0, 128.0)
        .build()
    );

    // Shader

    private final Setting<ShaderMode> shaderMode = sgShader.add(new EnumSetting.Builder<ShaderMode>()
        .name("shader-mode")
        .description("The shader program to use.")
        .defaultValue(ShaderMode.Outline)
        .build()
    );

    private final Setting<Mode> mode = sgShader.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("The rendering that will be applied to the target.")
        .defaultValue(Mode.Both)
        .visible(() -> shaderMode.get() == ShaderMode.Outline)
        .build()
    );

    private final Setting<SettingColor> fillColor = sgShader.add(new ColorSetting.Builder()
        .name("fill-color")
        .description("The color that will be used for the fill rendering.")
        .defaultValue(new SettingColor(255, 255, 255, 45))
        .build()
    );

    private final Setting<SettingColor> outlineColor = sgShader.add(new ColorSetting.Builder()
        .name("outline-color")
        .description("The color that will be used for the outline rendering.")
        .defaultValue(new SettingColor(255, 255, 255, 200))
        .visible(() -> shaderMode.get() == ShaderMode.Outline && mode.get() != Mode.Fill)
        .build()
    );

    private final Setting<Double> outlineWidth = sgShader.add(new DoubleSetting.Builder()
        .name("outline-width")
        .description("The width of the outline effect.")
        .defaultValue(1.0)
        .range(0.1, 3.0)
        .sliderRange(0.1, 3.0)
        .visible(() -> shaderMode.get() == ShaderMode.Outline && mode.get() != Mode.Fill)
        .build()
    );

    private final Setting<FriendsMode> friends = sgShader.add(new EnumSetting.Builder<FriendsMode>()
        .name("friends")
        .description("The color that will be applied to friended entities.")
        .defaultValue(FriendsMode.Default)
        .visible(() -> shaderMode.get() == ShaderMode.Outline)
        .build()
    );

    private final Setting<SettingColor> friendColor = sgShader.add(new ColorSetting.Builder()
        .name("friend-color")
        .description("The color that will be used for the shader effect on friends.")
        .defaultValue(new SettingColor(85, 255, 255, 60))
        .visible(() -> shaderMode.get() == ShaderMode.Outline && friends.get() == FriendsMode.Custom)
        .build()
    );

    // Bloom

    private final Setting<Double> bloomOutlineWidth = sgBloom.add(new DoubleSetting.Builder()
        .name("outline-width")
        .description("The width of the outline.")
        .defaultValue(1.0)
        .range(0.0, 5.0)
        .sliderRange(0.0, 5.0)
        .visible(() -> shaderMode.get() == ShaderMode.Bloom)
        .build()
    );

    private final Setting<Double> outlineOpacity = sgBloom.add(new DoubleSetting.Builder()
        .name("outline-opacity")
        .description("Opacity for the outline.")
        .defaultValue(1.0)
        .range(0.0, 1.0)
        .sliderRange(0.0, 1.0)
        .visible(() -> shaderMode.get() == ShaderMode.Bloom)
        .build()
    );

    private final Setting<Boolean> glowInside = sgBloom.add(new BoolSetting.Builder()
        .name("glow-inwards")
        .description("Glow inside the fill.")
        .defaultValue(false)
        .visible(() -> shaderMode.get() == ShaderMode.Bloom)
        .build()
    );

    private final Setting<Double> glowFactor = sgBloom.add(new DoubleSetting.Builder()
        .name("glow-factor")
        .description("Intensity multiplier for the glow.")
        .defaultValue(1.0)
        .range(0.0, 5.0)
        .sliderRange(0.0, 5.0)
        .visible(() -> shaderMode.get() == ShaderMode.Bloom)
        .build()
    );

    private final Setting<Integer> glowQuality = sgBloom.add(new IntSetting.Builder()
        .name("glow-quality")
        .description("Sampling quality for the glow blur.")
        .defaultValue(2)
        .range(1, 5)
        .sliderRange(1, 5)
        .visible(() -> shaderMode.get() == ShaderMode.Bloom)
        .build()
    );

    // Fill

    private final Setting<FillMode> fillMode = sgFill.add(new EnumSetting.Builder<FillMode>()
        .name("fill-mode")
        .description("The fill effect applied to the target.")
        .defaultValue(FillMode.Default)
        .build()
    );

    private final Setting<SettingColor> gradientColor = sgFill.add(new ColorSetting.Builder()
        .name("gradient-color")
        .description("Color for the gradient fill effect.")
        .defaultValue(new SettingColor(255, 0, 0, 255))
        .visible(() -> fillMode.get() == FillMode.Gradient)
        .build()
    );

    private final Setting<Double> gradientFactor = sgFill.add(new DoubleSetting.Builder()
        .name("gradient-factor")
        .description("Spread of the gradient effect.")
        .defaultValue(200.0)
        .range(1.0, 500.0)
        .sliderRange(1.0, 500.0)
        .visible(() -> fillMode.get() == FillMode.Gradient)
        .build()
    );

    private static ShadersModule instance;

    /**
     * Cached instance for the render mixins — avoids a Modules map lookup per
     * entity per frame. The module is constructed at client init, before any
     * rendering happens.
     */
    public static ShadersModule get() {
        return instance;
    }

    public ShadersModule() {
        super(AddonTemplate.CATEGORY, "shaders", "Overlays specified entities with a customizable shader. (ported from Zen)");
        instance = this;
    }

    //region Hooks called from mixins

    public void onWorldRenderPrepare() {
        if (!isActive() || mc.player == null || mc.world == null) return;
        ShaderManager.get().prepare();
    }

    public VertexConsumerProvider onRenderEntity(Entity entity, VertexConsumerProvider vertexConsumers) {
        if (!isActive() || mc.player == null || mc.world == null || !isValidEntity(entity)) return vertexConsumers;

        SettingColor color = fillColor.get();
        if (entity instanceof PlayerEntity player && Friends.get().isFriend(player) && friends.get() != FriendsMode.Sync) {
            color = friends.get() == FriendsMode.Default
                ? new SettingColor(DEFAULT_FRIEND_COLOR.r, DEFAULT_FRIEND_COLOR.g, DEFAULT_FRIEND_COLOR.b, fillColor.get().a)
                : friendColor.get();
        }

        return ShaderManager.get().create(vertexConsumers, color.r, color.g, color.b);
    }

    public void onRenderEntitiesPost() {
        if (!isActive() || mc.player == null || mc.world == null) return;

        if (players.get() || hostiles.get() || animals.get() || ambient.get() || invisibles.get() || items.get() || crystals.get() || others.get()) {
            ShaderManager.get().getVertexConsumerProvider().draw();
        }

        if (!hands.get()) renderShader();
    }

    public VertexConsumerProvider onRenderHand(VertexConsumerProvider vertexConsumers) {
        if (!isActive() || mc.player == null || mc.world == null || !hands.get()) return vertexConsumers;

        return ShaderManager.get().create(vertexConsumers, fillColor.get().r, fillColor.get().g, fillColor.get().b);
    }

    public void onRenderHandPost() {
        if (!isActive() || mc.player == null || mc.world == null || !hands.get()) return;

        ShaderManager.get().getVertexConsumerProvider().draw();
    }

    public void onWorldRenderPost() {
        if (!isActive() || mc.player == null || mc.world == null || !hands.get()) return;

        renderShader();
    }

    //endregion

    private void renderShader() {
        SettingColor gradCol = gradientColor.get();
        int fillModeValue = switch (fillMode.get()) {
            case Gradient -> 1;
            case Rainbow -> 4;
            default -> 0;
        };

        ShaderManager.get().setFillSettings(fillModeValue,
            gradCol.r / 255.0f, gradCol.g / 255.0f, gradCol.b / 255.0f, gradCol.a / 255.0f,
            gradientFactor.get().floatValue());

        if (shaderMode.get() == ShaderMode.Bloom) {
            float shaderTime = (float) (System.currentTimeMillis() - startTime);

            int renderMode = switch (mode.get()) {
                case Fill -> 0;
                case Outline -> 1;
                default -> 2;
            };

            ShaderManager.get().render(
                "bloom",
                renderMode,
                fillColor.get().a / 255.0f,
                glowInside.get() ? 1 : 0,
                glowQuality.get(),
                glowFactor.get().floatValue(),
                bloomOutlineWidth.get().floatValue(),
                outlineOpacity.get().floatValue(),
                shaderTime);
        } else {
            int renderMode = switch (mode.get()) {
                case Fill -> 0;
                case Outline -> 1;
                default -> 2;
            };

            SettingColor friendCol = null;
            if (friends.get() == FriendsMode.Default) {
                friendCol = new SettingColor(DEFAULT_FRIEND_COLOR.r, DEFAULT_FRIEND_COLOR.g, DEFAULT_FRIEND_COLOR.b, fillColor.get().a);
            } else if (friends.get() == FriendsMode.Custom) {
                friendCol = friendColor.get();
            }

            SettingColor outlineCol = outlineColor.get();
            ShaderManager.get().render(renderMode, fillColor.get().a / 255.0f,
                outlineCol.r, outlineCol.g, outlineCol.b, outlineCol.a,
                outlineWidth.get().floatValue(),
                friendCol != null ? friendCol.r : -1, friendCol != null ? friendCol.g : -1, friendCol != null ? friendCol.b : -1, friendCol != null ? friendCol.a : -1);
        }
    }

    public boolean isValidEntity(Entity entity) {
        if (mc.player == null) return false;
        // Squared check — avoids a sqrt per entity per frame.
        if (entity.squaredDistanceTo(mc.player) > distance.get() * distance.get()) return false;

        if (players.get() && entity.getType() == EntityType.PLAYER) return true;
        if (hostiles.get() && entity.getType().getSpawnGroup() == SpawnGroup.MONSTER) return true;
        if (animals.get() && (entity.getType().getSpawnGroup() == SpawnGroup.CREATURE || entity.getType().getSpawnGroup() == SpawnGroup.WATER_CREATURE || entity.getType().getSpawnGroup() == SpawnGroup.WATER_AMBIENT || entity.getType().getSpawnGroup() == SpawnGroup.UNDERGROUND_WATER_CREATURE || entity.getType().getSpawnGroup() == SpawnGroup.AXOLOTLS))
            return true;
        if (ambient.get() && entity.getType().getSpawnGroup() == SpawnGroup.AMBIENT) return true;
        if (invisibles.get() && entity.isInvisible()) return true;
        if (items.get() && (entity.getType() == EntityType.ITEM || entity.getType() == EntityType.EXPERIENCE_BOTTLE)) return true;
        if (crystals.get() && entity.getType() == EntityType.END_CRYSTAL) return true;
        return others.get();
    }
}
