package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import com.example.addon.chams.Glint;
import com.example.addon.chams.ModelRenderer;
import com.example.addon.chams.Renderer3D;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.awt.Color;

/**
 * Ported from Zen's ChamsModule: draws a flat colored / outlined copy of entity
 * and crystal models on top of the world (visible through walls), with optional
 * shine, scrolling glint texture, pulse, friend colors and damage color. XQZ
 * additionally renders the textured vanilla model through walls at a custom
 * opacity.
 */
public class ChamsModule extends Module {
    public enum Mode { Fill, Outline, Both }
    public enum FriendMode { Default, Custom, Sync }
    public enum GlintDirection { Diagonal, Horizontal, Vertical }

    private static ChamsModule instance;

    /** Cached instance for the render mixins. */
    public static ChamsModule get() {
        return instance;
    }

    private static final long startTime = System.currentTimeMillis();
    private static final SettingColor DEFAULT_FRIEND_COLOR = new SettingColor(85, 255, 255);

    private final SettingGroup sgGeneral = settings.createGroup("General");
    private final SettingGroup sgEntities = settings.createGroup("Entities");
    private final SettingGroup sgCrystals = settings.createGroup("Crystals");

    // General

    private final Setting<Boolean> shine = sgGeneral.add(new BoolSetting.Builder()
        .name("shine")
        .description("Adds a shine effect to the chams.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> shineOpacity = sgGeneral.add(new DoubleSetting.Builder()
        .name("shine-opacity")
        .description("Opacity of the shine effect.")
        .defaultValue(1.0)
        .range(0.0, 1.0)
        .sliderRange(0.0, 1.0)
        .visible(shine::get)
        .build()
    );

    private final Setting<Boolean> glint = sgGeneral.add(new BoolSetting.Builder()
        .name("glint")
        .description("Adds a scrolling texture overlay to the chams.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> glintOpacity = sgGeneral.add(new DoubleSetting.Builder()
        .name("glint-opacity")
        .description("Opacity of the glint overlay.")
        .defaultValue(1.0)
        .range(0.0, 1.0)
        .sliderRange(0.0, 1.0)
        .visible(glint::get)
        .build()
    );

    private final Setting<SettingColor> glintColor = sgGeneral.add(new ColorSetting.Builder()
        .name("glint-color")
        .description("Color tint for the glint overlay.")
        .defaultValue(new SettingColor(255, 255, 255, 180))
        .visible(glint::get)
        .build()
    );

    private final Setting<Double> glintSpeedU = sgGeneral.add(new DoubleSetting.Builder()
        .name("glint-speed-u")
        .description("Horizontal scroll speed of the glint texture.")
        .defaultValue(0.25)
        .range(-5.0, 5.0)
        .sliderRange(-1.0, 1.0)
        .visible(glint::get)
        .build()
    );

    private final Setting<Double> glintSpeedV = sgGeneral.add(new DoubleSetting.Builder()
        .name("glint-speed-v")
        .description("Vertical scroll speed of the glint texture.")
        .defaultValue(0.10)
        .range(-5.0, 5.0)
        .sliderRange(-1.0, 1.0)
        .visible(glint::get)
        .build()
    );

    private final Setting<Double> glintScale = sgGeneral.add(new DoubleSetting.Builder()
        .name("glint-scale")
        .description("Scale of the glint texture on the model.")
        .defaultValue(1.0)
        .range(0.1, 5.0)
        .sliderRange(0.1, 5.0)
        .visible(glint::get)
        .build()
    );

    private final Setting<GlintDirection> glintDirection = sgGeneral.add(new EnumSetting.Builder<GlintDirection>()
        .name("glint-direction")
        .description("Projection mode for the glint UV coordinates.")
        .defaultValue(GlintDirection.Diagonal)
        .visible(glint::get)
        .build()
    );

    private final Setting<SettingColor> fillColor = sgGeneral.add(new ColorSetting.Builder()
        .name("fill-color")
        .description("Fill color for all chams (entities & crystals).")
        .defaultValue(new SettingColor(255, 255, 255, 60))
        .build()
    );

    private final Setting<SettingColor> outlineColor = sgGeneral.add(new ColorSetting.Builder()
        .name("outline-color")
        .description("Outline color for all chams (entities & crystals).")
        .defaultValue(new SettingColor(255, 255, 255, 200))
        .build()
    );

    // Entities

    private final Setting<Boolean> players = sgEntities.add(new BoolSetting.Builder()
        .name("players")
        .description("Renders chams on player entities.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> hostiles = sgEntities.add(new BoolSetting.Builder()
        .name("hostiles")
        .description("Renders chams on hostile entities.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> passives = sgEntities.add(new BoolSetting.Builder()
        .name("passives")
        .description("Renders chams on passive entities.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> entityPulse = sgEntities.add(new BoolSetting.Builder()
        .name("pulse")
        .description("Adds a pulsing effect to entity cham opacity.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> entityXqz = sgEntities.add(new BoolSetting.Builder()
        .name("xqz")
        .description("Renders entities through walls.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> entityXqzOpacity = sgEntities.add(new DoubleSetting.Builder()
        .name("xqz-opacity")
        .description("Controls XQZ opacity.")
        .defaultValue(1.0)
        .range(0.0, 1.0)
        .sliderRange(0.0, 1.0)
        .visible(entityXqz::get)
        .build()
    );

    private final Setting<Mode> entityMode = sgEntities.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("Rendering type for living entities.")
        .defaultValue(Mode.Both)
        .build()
    );

    private final Setting<FriendMode> friendMode = sgEntities.add(new EnumSetting.Builder<FriendMode>()
        .name("friend-mode")
        .description("Friend color mode.")
        .defaultValue(FriendMode.Default)
        .visible(() -> entityMode.get() != Mode.Outline)
        .build()
    );

    private final Setting<SettingColor> friendFillColor = sgEntities.add(new ColorSetting.Builder()
        .name("friend-fill-color")
        .description("Friend fill color.")
        .defaultValue(new SettingColor(85, 255, 255, 60))
        .visible(() -> entityMode.get() != Mode.Outline && friendMode.get() == FriendMode.Custom)
        .build()
    );

    private final Setting<SettingColor> friendOutlineColor = sgEntities.add(new ColorSetting.Builder()
        .name("friend-outline-color")
        .description("Friend outline color.")
        .defaultValue(new SettingColor(85, 255, 255, 200))
        .visible(() -> entityMode.get() != Mode.Fill && friendMode.get() == FriendMode.Custom)
        .build()
    );

    private final Setting<Boolean> damageModify = sgEntities.add(new BoolSetting.Builder()
        .name("damage-modify")
        .description("Changes color when damaged.")
        .defaultValue(false)
        .visible(() -> entityMode.get() != Mode.Outline)
        .build()
    );

    private final Setting<SettingColor> damageColor = sgEntities.add(new ColorSetting.Builder()
        .name("damage-color")
        .description("Damage color.")
        .defaultValue(new SettingColor(255, 0, 0, 255))
        .visible(() -> damageModify.get() && entityMode.get() != Mode.Outline)
        .build()
    );

    // Crystals

    private final Setting<Boolean> crystals = sgCrystals.add(new BoolSetting.Builder()
        .name("crystals")
        .description("Renders chams on crystals.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> crystalPulse = sgCrystals.add(new BoolSetting.Builder()
        .name("pulse")
        .description("Adds a pulsing effect to crystal cham opacity.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> crystalXqz = sgCrystals.add(new BoolSetting.Builder()
        .name("xqz")
        .description("Renders crystals through walls.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> crystalXqzOpacity = sgCrystals.add(new DoubleSetting.Builder()
        .name("xqz-opacity")
        .description("Controls XQZ opacity.")
        .defaultValue(1.0)
        .range(0.0, 1.0)
        .sliderRange(0.0, 1.0)
        .visible(crystalXqz::get)
        .build()
    );

    private final Setting<Mode> crystalMode = sgCrystals.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("Rendering type for crystals.")
        .defaultValue(Mode.Both)
        .build()
    );

    public ChamsModule() {
        // NOT "chams": Meteor's Modules.add() removes the previous module with the
        // same name, which would unregister Meteor's built-in Chams module and NPE
        // its ChamsShader on every frame.
        super(AddonTemplate.CATEGORY, "zen-chams", "Adds a customizable render on top of the default Minecraft rendering. (ported from Zen)");
        instance = this;
    }

    /**
     * Collects the cham geometry for this frame; called between Renderer3D.prepare()
     * and Renderer3D.draw() from the WorldRenderer mixin.
     */
    public void onRenderWorld(float tickDelta) {
        if (mc.world == null) return;

        Glint.speedU = glintSpeedU.get().floatValue();
        Glint.speedV = glintSpeedV.get().floatValue();
        Glint.scale = glintScale.get().floatValue();
        Glint.direction = glintDirection.get().name();
        Glint.tick();

        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player && mc.options.getPerspective().isFirstPerson()) continue;
            if (!Renderer3D.isFrustumVisible(entity.getBoundingBox())) continue;

            if (entity instanceof LivingEntity livingEntity && !(entity instanceof EndCrystalEntity)) {
                if (!isValidEntity(livingEntity)) continue;

                boolean damaged = damageModify.get() && livingEntity.hurtTime > 0;

                SettingColor fill;
                SettingColor outline;
                if (livingEntity instanceof PlayerEntity player && Friends.get().isFriend(player) && friendMode.get() != FriendMode.Sync) {
                    fill = friendColor(friendFillColor, damaged);
                    outline = friendColor(friendOutlineColor, damaged);
                } else {
                    fill = damaged ? withAlpha(damageColor.get(), fillColor.get().a) : fillColor.get();
                    outline = damaged ? withAlpha(damageColor.get(), outlineColor.get().a) : outlineColor.get();
                }

                ModelRenderer.renderModel(livingEntity, 1.0f, tickDelta,
                    new ModelRenderer.Render(
                        entityMode.get() != Mode.Outline,
                        entityPulse.get() ? pulse(applyShine(fill)) : applyShine(fill),
                        entityMode.get() != Mode.Fill,
                        entityPulse.get() ? pulse(applyShine(outline)) : applyShine(outline),
                        shine.get(),
                        glint.get(),
                        applyGlint(glintColor.get())
                    )
                );
            }

            if (crystals.get() && entity instanceof EndCrystalEntity crystal) {
                SettingColor fill = crystalPulse.get() ? pulse(applyShine(fillColor.get())) : applyShine(fillColor.get());
                SettingColor outline = crystalPulse.get() ? pulse(applyShine(outlineColor.get())) : applyShine(outlineColor.get());

                ModelRenderer.renderModel(crystal, 1.0f, tickDelta,
                    new ModelRenderer.Render(
                        crystalMode.get() != Mode.Outline,
                        fill,
                        crystalMode.get() != Mode.Fill,
                        outline,
                        shine.get(),
                        glint.get(),
                        applyGlint(glintColor.get())
                    )
                );
            }
        }
    }

    private SettingColor friendColor(Setting<SettingColor> base, boolean damaged) {
        if (damaged) return withAlpha(damageColor.get(), base.get().a);
        if (friendMode.get() == FriendMode.Default) return withAlpha(DEFAULT_FRIEND_COLOR, base.get().a);
        return base.get();
    }

    private static SettingColor withAlpha(SettingColor color, int alpha) {
        return new SettingColor(color.r, color.g, color.b, alpha);
    }

    /** Shine replaces the blend mode of the whole cham draw; scale its alpha. */
    private SettingColor applyShine(SettingColor color) {
        if (!shine.get()) return color;
        return scaleAlpha(color, shineOpacity.get());
    }

    private SettingColor applyGlint(SettingColor color) {
        return scaleAlpha(color, glintOpacity.get());
    }

    private static SettingColor scaleAlpha(SettingColor color, double mult) {
        int alpha = Math.max(0, Math.min(255, (int) Math.round(color.a * mult)));
        return new SettingColor(color.r, color.g, color.b, alpha);
    }

    private static SettingColor pulse(SettingColor color) {
        double sin = Math.sin(2 * Math.PI * (15.0 / 20.0) * ((System.currentTimeMillis() - startTime) / 1000.0));
        double scale = (sin + 1) / 2;
        return new SettingColor(color.r, color.g, color.b, (int) (color.a * scale));
    }

    public boolean isValidEntity(Entity entity) {
        if (players.get() && entity.getType() == EntityType.PLAYER) return true;
        if (hostiles.get() && entity.getType().getSpawnGroup() == SpawnGroup.MONSTER) return true;
        if (crystals.get() && entity instanceof EndCrystalEntity) return true;
        return passives.get() && (entity.getType().getSpawnGroup() == SpawnGroup.CREATURE || entity.getType().getSpawnGroup() == SpawnGroup.WATER_CREATURE || entity.getType().getSpawnGroup() == SpawnGroup.WATER_AMBIENT || entity.getType().getSpawnGroup() == SpawnGroup.UNDERGROUND_WATER_CREATURE || entity.getType().getSpawnGroup() == SpawnGroup.AXOLOTLS);
    }

    public boolean isXqzEntity(Entity entity) {
        return isActive() && entityXqz.get() && isValidEntity(entity);
    }

    public boolean isXqzCrystal(EndCrystalEntity entity) {
        return isActive() && crystalXqz.get() && isValidEntity(entity);
    }

    public float getXqzEntityOpacity() {
        return entityXqzOpacity.get().floatValue();
    }

    public float getXqzCrystalOpacity() {
        return crystalXqzOpacity.get().floatValue();
    }
}
