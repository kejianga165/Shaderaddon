package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;

/**
 * Smoothly lowers your held item / hands while you are moving and raises them
 * back to the original position once you stop.
 */
public class HandSwayModule extends Module {
    private static HandSwayModule instance;

    /** Cached instance for the render mixin — set in the constructor. */
    public static HandSwayModule get() {
        return instance;
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> strength = sgGeneral.add(new DoubleSetting.Builder()
        .name("strength")
        .description("How far the hand lowers while moving.")
        .defaultValue(0.15)
        .range(0.0, 0.5)
        .sliderRange(0.0, 0.4)
        .build()
    );

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
        .name("speed")
        .description("How quickly the hand lowers and returns. Higher is snappier.")
        .defaultValue(10.0)
        .range(1.0, 20.0)
        .sliderRange(1.0, 20.0)
        .build()
    );

    // Sprinting is ~0.28 blocks/tick, walking ~0.22; anything at or above full
    // sprint counts as 100% lowered.
    private static final double FULL_SPRINT_SPEED = 0.28;

    private double smoothed;
    private long lastNano;

    public HandSwayModule() {
        super(AddonTemplate.CATEGORY, "hand-sway", "Lowers your held item while moving and returns it when you stop.");
        instance = this;
    }

    /**
     * Called once per first-person hand render. Progresses the smoothing towards
     * the movement target and returns the current downward offset.
     */
    public float update() {
        double target = 0.0;
        if (mc.player != null) {
            double vx = mc.player.getVelocity().x;
            double vz = mc.player.getVelocity().z;
            double speedBlocksPerTick = Math.sqrt(vx * vx + vz * vz);
            target = Math.min(speedBlocksPerTick / FULL_SPRINT_SPEED, 1.0);
        }

        long now = System.nanoTime();
        float dt = lastNano == 0 ? 1.0f / 60.0f : (now - lastNano) / 1_000_000_000.0f;
        lastNano = now;

        // Frame-rate independent exponential smoothing towards the target.
        double factor = 1.0 - Math.exp(-dt * speed.get());
        smoothed += (target - smoothed) * factor;

        return (float) (smoothed * strength.get());
    }

    @Override
    public void onDeactivate() {
        smoothed = 0.0;
        lastNano = 0;
    }
}
